# Workforce DOT production build

Source: current DOT.zip supplied by the site owner on 2026-10-01.

This build intentionally preserves the approved logo assets, navigation JavaScript, footer JavaScript, forms, checkout flows, login flows, management runtime, and production endpoint configuration from that source archive.

Updates in this build:
- Removed design-shell.html.
- Expanded Platform, Employers, and Owner-Operator pages using the approved homepage design system.
- Grounded product copy in the screenings4u Enterprise Workforce DOT feature catalog.
- Added missing production footer hookup where required.
- Normalized current shared CSS/JS cache-busting versions.
- Added canonical URLs to public marketing pages.
- Preserved existing production integrations and dynamic URL configuration.
